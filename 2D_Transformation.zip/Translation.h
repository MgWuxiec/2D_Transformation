#pragma once
#include "Transformation.h"
class Translation :
    public Transformation
{
public:
    Translation();
};

